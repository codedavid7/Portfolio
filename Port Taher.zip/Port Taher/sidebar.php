<div class="col-sm-4 ">
  <aside class="sidebar ptrbl-20">
    <div class="widget-area">
      <?php dynamic_sidebar('latest-album');?>
    </div>
  </aside>
</div>