<?php
/**
* Get the bootstrap
*/

if ( file_exists( __DIR__ . '/cmb2/init.php' ) ) {
	require_once __DIR__ . '/cmb2/init.php';
} elseif ( file_exists( __DIR__ . '/CMB2/init.php' ) ) {
	require_once __DIR__ . '/CMB2/init.php';
}

add_action( 'cmb2_admin_init', 'portfolio_master_cmb2' );
function portfolio_master_cmb2() {
		$prefix = '_portfolio_master_';

	$about_page_group = new_cmb2_box( array(
		'id'            => 'group_icon_metabox',
		'title'         => esc_html__( 'About Area Icon Metabox', 'portfolio_master' ),
		'object_types'  => array( 'about', ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
	) );
	$about_page_group->add_field( array(
		'name'       => __( 'Icon Field', 'portfolio_master' ),
		'desc'       => __( 'Write here your icon class name Example: fa-bar-chart', 'portfolio_master' ),
		'id'         => $prefix .'icon_metafield',
		'type'       => 'text',
	) );


	$countto_meta = new_cmb2_box( array(
		'id'            => 'countto_metabox',
		'title'         => esc_html__( 'Countto Metabox', 'portfolio_master' ),
		'object_types'  => array( 'counter', ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
	) );
	$countto_meta->add_field( array(
		'name'       => __( 'Countto Icon', 'portfolio_master' ),
		'desc'       => __( 'Write here your count icon class name Example: fa-tasks', 'portfolio_master' ),
		'id'         => $prefix .'countto_icon',
		'type'       => 'text',
	) );
	$countto_meta->add_field( array(
		'name'       => __( 'Countto Number', 'portfolio_master' ),
		'desc'       => __( 'Write here your countto number', 'portfolio_master' ),
		'id'         => $prefix .'countto_number',
		'type'       => 'text',
	) );


	$services_meta = new_cmb2_box( array(
		'id'            => 'services_metabox',
		'title'         => esc_html__( 'Services Metabox', 'portfolio_master' ),
		'object_types'  => array( 'services', ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
	) );
	$services_meta->add_field( array(
		'name'       => __( 'Services Icon', 'portfolio_master' ),
		'desc'       => __( 'Write here your services icon class name Example: fa-desktop', 'portfolio_master' ),
		'id'         => $prefix .'services_icon',
		'type'       => 'text',
	) );


	$portfolio_meta = new_cmb2_box( array(
		'id'            => 'portfolio_metabox',
		'title'         => esc_html__( 'Portfolio Metabox', 'portfolio_master' ),
		'object_types'  => array( 'works', ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
	) );
	$portfolio_meta->add_field( array(
		'name'       => __( 'Portfolio Link Text', 'portfolio_master' ),
		'desc'       => __( 'Write here your portfolio link text', 'portfolio_master' ),
		'id'         => $prefix .'portfolio_link_text',
		'type'       => 'text',
	) );
	$portfolio_meta->add_field( array(
		'name'       => __( 'Portfolio Link URL', 'portfolio_master' ),
		'desc'       => __( 'Write here your portfolio link url', 'portfolio_master' ),
		'id'         => $prefix .'portfolio_link_url',
		'type'       => 'text_url',
	) );


	$slider_meta = new_cmb2_box( array(
		'id'            => 'slider_metabox',
		'title'         => esc_html__( 'Slider Metabox', 'portfolio_master' ),
		'object_types'  => array( 'slider', ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
	) );
	$slider_meta->add_field( array(
		'name'       => __( 'Slider Heading', 'portfolio_master' ),
		'desc'       => __( 'Write here your portfolio link text', 'portfolio_master' ),
		'id'         => $prefix .'slider_heading',
		'type'       => 'text',
	) );
	$slider_meta->add_field( array(
		'name'       => __( 'Slider Button Text', 'portfolio_master' ),
		'desc'       => __( 'Write here your slider button text', 'portfolio_master' ),
		'id'         => $prefix .'slider_button',
		'type'       => 'text',
	) );
	$slider_meta->add_field( array(
		'name'       => __( 'Slider Heading WOW', 'portfolio_master' ),
		'desc'       => __( 'Write here your slider heading wow Example: bounceInLeft', 'portfolio_master' ),
		'id'         => $prefix .'slider_heading_wow',
		'type'       => 'text',
	) );
	$slider_meta->add_field( array(
		'name'       => __( 'Slider Title WOW', 'portfolio_master' ),
		'desc'       => __( 'Write here your slider title wow Example: bounceInLeft', 'portfolio_master' ),
		'id'         => $prefix .'slider_title_wow',
		'type'       => 'text',
	) );
	$slider_meta->add_field( array(
		'name'       => __( 'Slider Content WOW', 'portfolio_master' ),
		'desc'       => __( 'Write here your slider content wow Example: bounceInLeft', 'portfolio_master' ),
		'id'         => $prefix .'slider_content_wow',
		'type'       => 'text',
	) );
	$slider_meta->add_field( array(
		'name'       => __( 'Slider Button WOW', 'portfolio_master' ),
		'desc'       => __( 'Write here your slider button wow Example: bounceInLeft', 'portfolio_master' ),
		'id'         => $prefix .'slider_button_wow',
		'type'       => 'text',
	) );

	// $about_group_para = $about_page_group->add_field( array(
	// 	'name'       => __( 'Groupable Social Icon', 'office_master' ),
	// 	'id'         => $prefix .'group_icon_metafield',
	// 	'type'       => 'group',
	// ) );
	// $about_page_group->add_group_field($about_group_para, array(
	// 	'name'       => __( 'Social Icon Wow Class Name', 'office_master' ),
	// 	'id'         => $prefix .'header_social_icon_wow',
	// 	'type'       => 'text',
	// ) );
	// $about_page_group->add_group_field($about_group_para, array(
	// 	'name'       => __( 'Social Icon Class Name', 'office_master' ),
	// 	'id'         => $prefix .'header_social_icon',
	// 	'type'       => 'text',
	// ) );
	// $about_page_group->add_group_field($about_group_para, array(
	// 	'name'       => __( 'Social link', 'office_master' ),
	// 	'id'         => $prefix .'header_social_link',
	// 	'type'       => 'text_url',
	// ) );



	



	// $about_tab_post = new_cmb2_box( array(
	// 	'id'            => 'about_metabox',
	// 	'title'         => esc_html__( 'About Tab Metabox', 'office_master' ),
	// 	'object_types'  => array( 'about', ), // Post type
	// 	'context'    => 'normal',
	// 	'priority'   => 'high',
	// 	'show_names' => true, // Show field names on the left
	// ) );
	// $about_tab_post->add_field( array(
	// 	'name'       => __( 'Tab title', 'office_master' ),
	// 	'desc'       => __( 'Write here your countto number', 'office_master' ),
	// 	'id'         => $prefix .'tab_name',
	// 	'type'       => 'text',
	// ) );


	// $skill_post = new_cmb2_box( array(
	// 	'id'            => 'skill_metabox',
	// 	'title'         => esc_html__( 'Skill Metabox', 'office_master' ),
	// 	'object_types'  => array( 'skills', ), // Post type
	// 	'context'    => 'normal',
	// 	'priority'   => 'high',
	// 	'show_names' => true, // Show field names on the left
	// ) );
	// $skill_post->add_field( array(
	// 	'name'       => __( 'Skill Percent', 'office_master' ),
	// 	'desc'       => __( 'Write here your skill percent number', 'office_master' ),
	// 	'id'         => $prefix .'skill_percent',
	// 	'type'       => 'text',
	// ) );


	// $services_tab_post = new_cmb2_box( array(
	// 	'id'            => 'services_metabox',
	// 	'title'         => esc_html__( 'Services Metabox', 'office_master' ),
	// 	'object_types'  => array( 'services', ), // Post type
	// 	'context'    => 'normal',
	// 	'priority'   => 'high',
	// 	'show_names' => true, // Show field names on the left
	// ) );
	// $services_tab_post->add_field( array(
	// 	'name'       => __( 'Services Tab Icon', 'office_master' ),
	// 	'desc'       => __( 'Write here your tab icon class name <br> example: icon-alarm', 'office_master' ),
	// 	'id'         => $prefix .'services_tab_icon',
	// 	'type'       => 'text',
	// ) );
	// $services_tab_post->add_field( array(
	// 	'name'       => __( 'Services Tab Name', 'office_master' ),
	// 	'desc'       => __( 'Write here your tab name', 'office_master' ),
	// 	'id'         => $prefix .'services_tab_name',
	// 	'type'       => 'text',
	// ) );




	// $testimonial_tab_post = new_cmb2_box( array(
	// 	'id'            => 'testimonial_metabox',
	// 	'title'         => esc_html__( 'Testimonial Metabox', 'office_master' ),
	// 	'object_types'  => array( 'testimonial', ), // Post type
	// 	'context'    => 'normal',
	// 	'priority'   => 'high',
	// 	'show_names' => true, // Show field names on the left
	// ) );
	// $testimonial_tab_post->add_field( array(
	// 	'name'       => __( 'Testimonial Tab Name', 'office_master' ),
	// 	'desc'       => __( 'Write here your tab name', 'office_master' ),
	// 	'id'         => $prefix .'testimonial_tab_name',
	// 	'type'       => 'text',
	// ) );




	// $pricing_plan_post = new_cmb2_box( array(
	// 	'id'            => 'pricing_metabox',
	// 	'title'         => esc_html__( 'Pricing Metabox', 'office_master' ),
	// 	'object_types'  => array( 'pricing', ), // Post type
	// 	'context'    => 'normal',
	// 	'priority'   => 'high',
	// 	'show_names' => true, // Show field names on the left
	// ) );
	// $pricing_plan_post->add_field( array(
	// 	'name'       => __( 'Pricing Wow Animation', 'office_master' ),
	// 	'desc'       => __( 'Write here your wow class name', 'office_master' ),
	// 	'id'         => $prefix .'pricing_wow',
	// 	'type'       => 'text',
	// ) );
	// $pricing_plan_post->add_field( array(
	// 	'name'       => __( 'Pricing Amount', 'office_master' ),
	// 	'desc'       => __( 'Write here your price amount', 'office_master' ),
	// 	'id'         => $prefix .'pricing_amount',
	// 	'type'       => 'text',
	// ) );
	// 	$pricing_plan_post->add_field( array(
	// 	'name'       => __( 'Pricing Curency Sign', 'office_master' ),
	// 	'desc'       => __( 'Write here your curency Sign', 'office_master' ),
	// 	'id'         => $prefix .'curency_sign',
	// 	'type'       => 'text',
	// ) );
	// $pricing_plan_post->add_field( array(
	// 	'name'       => __( 'Pricing Work List', 'office_master' ),
	// 	'desc'       => __( 'Write here your Pricing Work list', 'office_master' ),
	// 	'id'         => $prefix .'pricing_work',
	// 	'repeatable'       => true,
	// 	'type'       => 'text',
	// ) );
	// $pricing_plan_post->add_field( array(
	// 	'name'       => __( 'Pricing Button Name', 'office_master' ),
	// 	'desc'       => __( 'Write here your pricing button name', 'office_master' ),
	// 	'id'         => $prefix .'pricing_button_name',
	// 	'type'       => 'text',
	// ) );



	// $testimonial_tab_post = new_cmb2_box( array(
	// 	'id'            => 'contact_metabox',
	// 	'title'         => esc_html__( 'Contact Metabox', 'office_master' ),
	// 	'object_types'  => array( 'contact', ), // Post type
	// 	'context'    => 'normal',
	// 	'priority'   => 'high',
	// 	'show_names' => true, // Show field names on the left
	// ) );
	// $testimonial_tab_post->add_field( array(
	// 	'name'       => __( 'Contact Icon Name', 'office_master' ),
	// 	'desc'       => __( 'Write here contact class name example: location_on', 'office_master' ),
	// 	'id'         => $prefix .'contact_name',
	// 	'type'       => 'text',
	// ) );


	// $testimonial_tab_post = new_cmb2_box( array(
	// 	'id'            => 'contact_metabox',
	// 	'title'         => esc_html__( 'Contact Metabox', 'office_master' ),
	// 	'object_types'  => array( 'onpage_menu', ), // Post type
	// 	'context'    => 'normal',
	// 	'priority'   => 'high',
	// 	'show_names' => true, // Show field names on the left
	// ) );
	// $testimonial_tab_post->add_field( array(
	// 	'name'       => __( 'Menu Name', 'office_master' ),
	// 	'desc'       => __( 'Write here onpage menu name', 'office_master' ),
	// 	'id'         => $prefix .'menu_name',
	// 	'type'       => 'text',
	// ) );
	// $testimonial_tab_post->add_field( array(
	// 	'name'       => __( 'Contact Icon Name', 'office_master' ),
	// 	'desc'       => __( 'Write here contact class name example: location_on', 'office_master' ),
	// 	'id'         => $prefix .'contact_name',
	// 	'type'       => 'text',
	// ) );

}