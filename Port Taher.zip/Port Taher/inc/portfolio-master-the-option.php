<?php

    /**
     * ReduxFramework Barebones Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    // This is your option name where all the Redux data is stored.
    $opt_name = "portfolio_master";

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => __( 'Portfolio Master Options', 'redux-framework-demo' ),
        'page_title'           => __( 'Portfolio Master Options', 'redux-framework-demo' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => true,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => true,
        // Show the time the page took to load, etc
        'update_notice'        => true,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '_options',
        // Page slug used to denote the panel
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!

        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        //'compiler'             => true,

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'light',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    // ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
    $args['admin_bar_links'][] = array(
        'id'    => 'redux-docs',
        'href'  => 'http://docs.reduxframework.com/',
        'title' => __( 'Documentation', 'redux-framework-demo' ),
    );

    $args['admin_bar_links'][] = array(
        //'id'    => 'redux-support',
        'href'  => 'https://github.com/ReduxFramework/redux-framework/issues',
        'title' => __( 'Support', 'redux-framework-demo' ),
    );

    $args['admin_bar_links'][] = array(
        'id'    => 'redux-extensions',
        'href'  => 'reduxframework.com/extensions',
        'title' => __( 'Extensions', 'redux-framework-demo' ),
    );

    // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
    $args['share_icons'][] = array(
        'url'   => 'https://github.com/ReduxFramework/ReduxFramework',
        'title' => 'Visit us on GitHub',
        'icon'  => 'el el-github'
        //'img'   => '', // You can use icon OR img. IMG needs to be a full URL.
    );
    $args['share_icons'][] = array(
        'url'   => 'https://www.facebook.com/pages/Redux-Framework/243141545850368',
        'title' => 'Like us on Facebook',
        'icon'  => 'el el-facebook'
    );
    $args['share_icons'][] = array(
        'url'   => 'http://twitter.com/reduxframework',
        'title' => 'Follow us on Twitter',
        'icon'  => 'el el-twitter'
    );
    $args['share_icons'][] = array(
        'url'   => 'http://www.linkedin.com/company/redux-framework',
        'title' => 'Find us on LinkedIn',
        'icon'  => 'el el-linkedin'
    );

    // Panel Intro text -> before the form
    if ( ! isset( $args['global_variable'] ) || $args['global_variable'] !== false ) {
        if ( ! empty( $args['global_variable'] ) ) {
            $v = $args['global_variable'];
        } else {
            $v = str_replace( '-', '_', $args['opt_name'] );
        }
        $args['intro_text'] = sprintf( __( '<p>Did you know that Redux sets a global variable for you? To access any of your saved options from within your code you can use your global variable: <strong>$%1$s</strong></p>', 'redux-framework-demo' ), $v );
    } else {
        $args['intro_text'] = __( '<p>This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.</p>', 'redux-framework-demo' );
    }

    // Add content after the form.
    $args['footer_text'] = __( '<p>This text is displayed below the options panel. It isn\'t required, but more info is always better! The footer_text field accepts all HTML.</p>', 'redux-framework-demo' );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */

    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => __( 'Theme Information 1', 'redux-framework-demo' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'redux-framework-demo' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => __( 'Theme Information 2', 'redux-framework-demo' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'redux-framework-demo' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'redux-framework-demo' );
    Redux::setHelpSidebar( $opt_name, $content );


    /*
     * <--- END HELP TABS
     */


    /*
     *
     * ---> START SECTIONS
     *
     */

    /*

        As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for


     */

    // -> START Basic Fields



        Redux::setSection( $opt_name, array(
        'title'  => 'Header Options',
        'id'     => 'header_options',
        'desc'   => 'This is header options',
        'icon'   => 'el el-home',
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Logo Option',
        'id'     => 'header_logo_options',
        'desc'   => 'This is logo option',
        'subsection' => true,
         'fields'     => array(
            array(
                'id'       => 'site_logo_1',
                'type'     => 'media',
                'title'    => 'Site Logo',
                'url'      => true,
                'desc'     => 'Upload your logo',
                'default'  => array(
                    'url'  => get_template_directory_uri().'/assets/img/LOGO-1.png'
                )
            ),
        )
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Header Image Option',
        'id'     => 'header_image_options',
        'desc'   => 'This is Image option',
        'subsection' => true,
         'fields'     => array(
            array(
                'id'       => 'header_image',
                'type'     => 'media',
                'title'    => 'Header Image',
                'url'      => true,
                'desc'     => 'Upload your Header Image',
                'default'  => array(
                    'url'  => get_template_directory_uri().'/assets/img/slider1.jpg'
                )
            ),
            array(
                'id'       => 'animate_heading',
                'type'     => 'slides',
                'title'    => 'Animate Heading Text',
                'desc'     => 'Write Your Animate Heading',
                'placeholder'    => array(
                    'title' => 'Write here your animate title',
                    'url' => ' Write here "visible" only fist slide',
                    'description' => 'NO',
                ),
            ),
            array(
                'id'       => 'header_slogan_wow',
                'type'     => 'select',
                'title'    => 'Header Slogan WOW',
                'desc'     => 'Select Your Animation Name',
                'default'  => 'bounceInLeft',
                'options'     => array(
                    'bounceInLeft' => 'bounceInLeft',
                    'bounceInRight' => 'bounceInRight', 
                ),
            ),
            array(
                'id'       => 'header_slogan',
                'type'     => 'text',
                'title'    => 'Header Slogan Text',
                'desc'     => 'Write Your Header Slogan Text',
                'default'  => 'There are three responses to a piece of design',
            ),
            array(
                'id'       => 'header_button_wow',
                'type'     => 'select',
                'title'    => 'Header Button WOW',
                'desc'     => 'Select Your Animation Name',
                'default'  => 'bounceInLeft',
                'options'     => array(
                    'bounceInLeft' => 'bounceInLeft',
                    'bounceInRight' => 'bounceInRight', 
                ),
            ),
            array(
                'id'       => 'header_button',
                'type'     => 'text',
                'title'    => 'Header Button Text',
                'desc'     => 'Write Your Header Button Text',
                'default'  => 'SEE MY WORKS',
            ),
        )
        ) );


        Redux::setSection( $opt_name, array(
        'title'  => 'About Options',
        'id'     => 'about_options',
        'desc'   => 'This is header options',
        'icon'   => 'el el-home',
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Heading Option',
        'id'     => 'about_heading_options',
        'desc'   => 'This is about heading option',
        'subsection' => true,
         'fields'     => array(
            array(
                'id'       => 'about_heading',
                'type'     => 'text',
                'title'    => ' About section heading',
                'desc'     => 'Write your section heading',
                'default'  => 'ABOUT ME'
            ),
        )
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Profile Option',
        'id'     => 'about_profile_options',
        'desc'   => 'This is about profile option',
        'subsection' => true,
         'fields'     => array(
            array(
                'id'       => 'about_profile_title',
                'type'     => 'text',
                'title'    => ' Profile Title',
                'desc'     => 'Write your profile title',
                'default'  => 'WHO AM I ?'
            ),
            array(
                'id'       => 'about_profile_desc',
                'type'     => 'editor',
                'title'    => ' Profile Description',
                'desc'     => 'Write your profile description',
                'default'  => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In vitae pretium nunc. Nullam efficitur ipsum neque, in dapibus orci venenatis at. Curabitur dignissim lobortis tincidunt. Fusce luctus nisl tellus, quis convallis ligula bibendum ac. Mauris odio arcu, vulputate in venenatis in, auctor in mauris. Nulla vel urna vitae mauris eleifend consectetur ut sed massa. Praesent quis nisi in enim feugiat suscipit.'
            ),
        )
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Skill Option',
        'id'     => 'about_skill_options',
        'desc'   => 'This is about skill option',
        'subsection' => true,
         'fields'     => array(
            array(
                'id'       => 'about_skill_title',
                'type'     => 'text',
                'title'    => ' Skill Title',
                'desc'     => 'Write your skill title',
                'default'  => 'MY SKILLS'
            ),
            array(
                'id'       => 'skill_bar',
                'type'     => 'slides',
                'title'    => 'Skills',
                'desc'     => 'Write Your Skill Name',
                'placeholder'    => array(
                    'title' => 'Write here your skill name Example: HTML',
                    'url' => ' Write here your skill percentage text Example: 50%',
                    'description' => 'Write here your skill percentage number Example: 50',
                ),
            ),
        )
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Process Option',
        'id'     => 'about_process_options',
        'desc'   => 'This is about skill option',
        'subsection' => true,
         'fields'     => array(
            array(
                'id'       => 'about_process_title',
                'type'     => 'text',
                'title'    => ' Process Title',
                'desc'     => 'Write your Process title',
                'default'  => 'THE PROCESS'
            ),
            array(
                'id'       => 'about_process_details',
                'type'     => 'editor',
                'title'    => 'Process Details',
                'desc'     => 'Write Your Process details',
                'default'  => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut mi ornare, pretium massa eu, rutrum enim. In in lorem congue, tincidunt justo at, consectetur nulla. Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
            ),
        )
        ) );


        Redux::setSection( $opt_name, array(
        'title'  => 'Status Options',
        'id'     => 'my_stutus_options',
        'desc'   => 'This is header options',
        'icon'   => 'el el-home',
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Status Option',
        'id'     => 'status_options',
        'desc'   => 'This is status option',
        'subsection' => true,
         'fields'     => array(
            array(
                'id'       => 'status_bg_image',
                'type'     => 'media',
                'title'    => ' Status Image',
                'url'      => true,
                'desc'     => 'Upload your status Image',
                'default'  => array(
                    'url'  => get_template_directory_uri().'/assets/img/counters-bg.jpg'
                )
            ),
            array(
                'id'       => 'status_heading',
                'type'     => 'text',
                'title'    => ' Status Heading',
                'desc'     => 'Write your status heading',
                'default'  => 'MY STATUS'
            ),
        )
        ) );

        Redux::setSection( $opt_name, array(
        'title'  => 'Services Options',
        'id'     => 'services_options',
        'desc'   => 'This is Services options',
        'icon'   => 'el el-home',
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Services Option',
        'id'     => 'services_section_options',
        'desc'   => 'This is services option',
        'subsection' => true,
         'fields'     => array(
            array(
                'id'       => 'services_heading',
                'type'     => 'text',
                'title'    => ' Services Heading',
                'desc'     => 'Write your Services heading',
                'default'  => 'SERVICES'
            ),
        )
        ) );

        Redux::setSection( $opt_name, array(
        'title'  => 'Portfolio Options',
        'id'     => 'portfolio_options',
        'desc'   => 'This is Portfolio options',
        'icon'   => 'el el-home',
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Portfolio Option',
        'id'     => 'portfolio_section_options',
        'desc'   => 'This is portfolio option',
        'subsection' => true,
         'fields'     => array(
            array(
                'id'       => 'portfolio_heading',
                'type'     => 'text',
                'title'    => ' Portfolio Heading',
                'desc'     => 'Write your Portfolio heading',
                'default'  => 'PORTFOLIO'
            ),
        )
        ) );

        Redux::setSection( $opt_name, array(
        'title'  => 'Testimonial Options',
        'id'     => 'testimonial_options',
        'desc'   => 'This is Testimonial options',
        'icon'   => 'el el-home',
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Testimonial Option',
        'id'     => 'testimonial_section_options',
        'desc'   => 'This is portfolio option',
        'subsection' => true,
         'fields'     => array(
            array(
                'id'       => 'testimonial_bg_image',
                'type'     => 'media',
                'title'    => ' Testimonial Image',
                'url'      => true,
                'desc'     => 'Upload your testimonial Image',
                'default'  => array(
                    'url'  => get_template_directory_uri().'/assets/img/slide1.jpg'
                )
            ),
            array(
                'id'       => 'testimonial_heading',
                'type'     => 'text',
                'title'    => ' Testimonial Heading',
                'desc'     => 'Write your Testimonial heading',
                'default'  => 'TESTIMONIAL'
            ),
        )
        ) );

        Redux::setSection( $opt_name, array(
        'title'  => 'Hire Options',
        'id'     => 'hire_options',
        'desc'   => 'This is Hire options',
        'icon'   => 'el el-home',
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Hire Option',
        'id'     => 'hire_section_options',
        'desc'   => 'This is portfolio option',
        'subsection' => true,
         'fields'     => array(
            array(
                'id'       => 'hire_title',
                'type'     => 'text',
                'title'    => ' Hire Title',
                'desc'     => 'Write your Hire Title',
                'default'  => 'WANT ME TO WORK ON YOUR NEXT PROJECT?'
            ),
            array(
                'id'       => 'hire_btn',
                'type'     => 'text',
                'title'    => ' Hire Button Text',
                'desc'     => 'Write your hire button text',
                'default'  => 'HIRE ME'
            ),
        )
        ) );



        Redux::setSection( $opt_name, array(
        'title'  => 'Contact Options',
        'id'     => 'contact_options',
        'desc'   => 'This is Contact options',
        'icon'   => 'el el-home',
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Contact Option',
        'id'     => 'contact_section_options',
        'desc'   => 'This is portfolio option',
        'subsection' => true,
         'fields'     => array(
            array(
                'id'       => 'contact_bg_image',
                'type'     => 'media',
                'title'    => ' Contact Background Image',
                'url'      => true,
                'desc'     => 'Upload your Contact Image',
                'default'  => array(
                    'url'  => get_template_directory_uri().'/assets/img/contact.jpg'
                )
            ),
            array(
                'id'       => 'contact_heading',
                'type'     => 'text',
                'title'    => ' Contact Heading',
                'desc'     => 'Write your contact heading',
                'default'  => 'CONTACT ME'
            ),
            array(
                'id'       => 'contact_address',
                'type'     => 'slides',
                'title'    => ' Contact Address',
                'placeholder'    => array(
                    'title' => 'Write here your contact address title',
                    'url' => ' Write here your contact icon class name Example: fa-envelope-o',
                    'description' => 'Write here your contact address title',
                ),
            ),
        )
        ) );


        Redux::setSection( $opt_name, array(
        'title'  => 'Footer Options',
        'id'     => 'footer_options',
        'desc'   => 'This is Footer options',
        'icon'   => 'el el-home',
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Footer Option',
        'id'     => 'footer_section_options',
        'desc'   => 'This is Footer option',
        'subsection' => true,
         'fields'     => array(
            array(
                'id'       => 'footer_heading',
                'type'     => 'text',
                'title'    => ' Footer Heading',
                'desc'     => 'Write your footer heading',
                'default'  => 'Abu Taher'
            ),
            array(
                'id'       => 'footer_icon',
                'type'     => 'slides',
                'title'    => ' Footer Icon',
                'placeholder'    => array(
                    'title' => 'Write here your footer icon class name Example: fa-facebook',
                    'url' => ' Write here your footer icon link url',
                    'description' => 'NO',
                ),
            ),
            array(
                'id'       => 'footer_copy',
                'type'     => 'editor',
                'title'    => ' Copyright Text',
                'desc'     => 'Write here your copyright text',
                'default'  => 'All copyright © reserved by Abu Taher 2017'
            ),
            array(
                'id'       => 'scrol_icon',
                'type'     => 'text',
                'title'    => ' fa-angle-up',
                'desc'     => 'Write here your scroll icon class name',
                'default'  => 'fa-angle-up'
            ),
        )
        ) );

        Redux::setSection( $opt_name, array(
        'title'  => 'Single Options',
        'id'     => 'single_options',
        'desc'   => 'This is Single options',
        'icon'   => 'el el-home',
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Single Option',
        'id'     => 'single_section_options',
        'desc'   => 'This is Single option',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'single_image',
                'type'     => 'media',
                'title'    => ' Single Image',
                'url'      => true,
                'desc'     => 'Upload your single page image',
                'default'  => array(
                    'url'  => get_template_directory_uri().'/assets/img/slide1.jpg',
                )
            ),
        )
        ) );

        Redux::setSection( $opt_name, array(
        'title'  => 'Blog Options',
        'id'     => 'blog_options',
        'desc'   => 'This is blog options',
        'icon'   => 'el el-home',
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Blog Option',
        'id'     => 'blog_section_options',
        'desc'   => 'This is blog option',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'blog_button',
                'type'     => 'text',
                'title'    => ' Blog Button Text',
                'desc'     => 'Write here your blog button text',
                'default'  => 'see all post'
            ),
        )
        ) );




        Redux::setSection( $opt_name, array(
        'title'  => 'Theme Design Options',
        'id'     => 'theme_options',
        'desc'   => 'This is theme design options',
        'icon'   => 'el el-home',
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Theme Design Option',
        'id'     => 'theme_section_options',
        'desc'   => 'This is theme design option',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'opt_color_title',
                'type'     => 'color',
                'output'   => array( 'body h1, h2, h3, h4, h5' ),
                'title'    => __( 'Site Section Heading Color', 'redux-framework-demo' ),
                'subtitle' => __( 'Pick a title color for the theme (default: #000).', 'redux-framework-demo' ),
            ),
            array(
                'id'       => 'opt_color_border',
                'type'     => 'color',
                'output'   => array( 'i.fa' ),
                'title'    => __( 'Site Icon Color', 'redux-framework-demo' ),
                'subtitle' => __( 'Pick a icon color for the theme.', 'redux-framework-demo' ),
            ),
            array(
                'id'       => 'opt_color_paragraph',
                'type'     => 'color',
                'output'   => array( 'p' ),
                'title'    => __( 'Site Paragraph Color', 'redux-framework-demo' ),
                'subtitle' => __( 'Pick a Paragraph color for the theme.', 'redux-framework-demo' ),
            ),
        )
        ) );


        Redux::setSection( $opt_name, array(
        'title'  => 'Theme Sorter Options',
        'id'     => 'theme_sorter',
        'desc'   => 'This is Section Sorter design options',
        'icon'   => 'el el-home',
        ) );
        Redux::setSection( $opt_name, array(
        'title'  => 'Theme Sorter Option',
        'id'     => 'theme_sorter_options',
        'desc'   => 'This is Section Sorter design option',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'opt_sorter',
                'type'     => 'sorter',
                'options'   => array (
                    'Active'=> array(
                        'slider'=>'SLIDER',
                        'about'=>'ABOUT',
                        'process'=>'PROCESS',
                        'counter'=>'COUNTER',
                        'sevices'=>'SERVICES',
                        'portfolio'=>'PORTFOLIO',
                        'testimonial'=>'TESTIMONIAL',
                        'blog'=>'BLOG',
                        'hire'=>'HIRE',
                        'contact'=>'CONTACT',
                    ),
                    'Deactive'=> array(
                        
                    )
                )
            ),
        )
        ) );









      



    /*
     * <--- END SECTIONS
     */
