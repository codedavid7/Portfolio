<?php global $portfolio_master; ?>
    <!-- Hire Area Start -->
    <section class="hire-section section ">
      <div class="container">
        <div class="hire-project text-center">
          <h2 class="mb-20"><?php echo $portfolio_master['hire_title']; ?></h2>
          <a href="#" class="common-btn"><?php echo $portfolio_master['hire_btn']; ?></a>
        </div>
      </div>
    </section>
    <!-- Hire Area End -->